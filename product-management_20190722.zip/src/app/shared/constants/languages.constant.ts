export const LANGUAGES = [
    {
        name: 'English',
        code: 'en'
    },
    {
        name: 'Japanese',
        code: 'ja'
    }
];
