export const IMAGE_BASE_PATH = 'assets/images/';
