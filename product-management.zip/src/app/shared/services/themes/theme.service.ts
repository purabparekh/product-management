import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { THEMES } from '../../constants/themes.constant';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {

  /** Holds currently active theme name */
  currentTheme$: BehaviorSubject<string>;

  constructor() {
    this.currentTheme$ = new BehaviorSubject<string>(THEMES.GREEN);
  }

  /**
   * Emits a new theme name to apply
   */
  setTheme(theme: string) {
    this.currentTheme$.next(theme);
  }
}
