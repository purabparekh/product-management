import { Component, OnInit } from '@angular/core';
import { ThemeService } from 'src/app/shared/services/themes/theme.service';
import { THEMES } from 'src/app/shared/constants/themes.constant';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  themes = THEMES;

  constructor(private themeService: ThemeService) { }

  ngOnInit() {}
  onSetTheme(theme: string) {
    this.themeService.setTheme(theme);
  }
}
