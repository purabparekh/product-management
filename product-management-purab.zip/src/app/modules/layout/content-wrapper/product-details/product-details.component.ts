import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/shared/services/data-providers/products/products.service';
import { Product, IProduct } from 'src/app/shared/classes/product.class';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {

  product: Product;

  constructor(private productsService: ProductsService,
              private router: Router,
              private activatedRoute: ActivatedRoute) {
  }

  ngOnInit() {
    const productId = Number.parseInt(this.activatedRoute.snapshot.paramMap.get('id'), 10);
    const product = this.productsService.getProductById(productId);
    if (product) {
      this.product = product;
    } else {
      this.router.navigate(['products']);
    }
  }

  updateProduct() {
    const product = this.product;
    product.name = 'Purab';
    this.productsService.updateProductDetails(product);
  }

  deleteProduct() {
    this.productsService.deleteProduct(this.product.id);
    this.router.navigate(['products']);
  }

  addNewProduct() {
    const product: IProduct = {
      id: Math.ceil(100 + (Math.random() * 1000)),
      name: 'sdfgsdfgsd',
      price: 51,
      currency: 'USD',
      categories: [1, 2]
    };
    this.productsService.addNewProduct(product);
  }
}
