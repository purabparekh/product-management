import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { THEMES } from '../../constants/themes.constant';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {

  currentTheme$: BehaviorSubject<string>;

  constructor() {
    this.currentTheme$ = new BehaviorSubject<string>(THEMES.GREEN);
  }

  setTheme(theme: string) {
    this.currentTheme$.next(theme);
  }
}
