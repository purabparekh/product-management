import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Product, IProduct } from 'src/app/shared/classes/product.class';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  products$: BehaviorSubject<Array<Product>>;

  constructor() {
    this.products$ = new BehaviorSubject(this.getDefaultProducts());
  }

  getDefaultProducts(): Array<Product> {
    return [
      new Product({ id: 1, name: 'Fridge', price: 100, currency: 'USD', categories: [1] }),
      new Product({ id: 2, name: 'iPhone X', price: 150, currency: 'USD', categories: [1, 2] }),
      new Product({ id: 3, name: 'Macbook', price: 340, currency: 'USD', categories: [3] }),
    ];
  }

  getProductsByCategory(categoryId: number): BehaviorSubject<Array<Product>> {
    const productsInCategory$ = new BehaviorSubject(
      this.products$.value.filter((product: Product) => product.categories.includes(categoryId)));
    return productsInCategory$;
  }

  addNewProduct(product: IProduct) {
    const allProducts = this.products$.value;
    allProducts.push(product);
    this.products$.next(allProducts);
  }

  updateProductDetails(updatedProduct: IProduct) {
    const allProducts = this.products$.value;
    const productIndex = allProducts.findIndex(product => product.id === updatedProduct.id);
    if (productIndex >= 0) {
      const productToUpdate = allProducts[productIndex];
      const newProduct = new Product(Object.assign({}, productToUpdate, updatedProduct));
      allProducts.splice(productIndex, 1, newProduct);
      this.products$.next(allProducts);
    }
  }

  deleteProduct(productId: number) {
    const allProducts = this.products$.value;
    const productIndex = allProducts.findIndex(product => product.id === productId);
    if (productIndex >= 0) {
      allProducts.splice(productIndex, 1);
      this.products$.next(allProducts);
    }
  }

  getProductById(productId: number) {
    const allProducts = this.products$.value;
    return allProducts.find(product => product.id === productId);
  }
}
