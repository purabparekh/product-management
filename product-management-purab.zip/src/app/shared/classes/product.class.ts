export interface IProduct {
  id: number;
  name: string;
  price: number;
  currency: string;
  categories: Array<number>;
}

export class Product {
  id: number;
  name: string;
  price: number;
  currency: string;
  categories: Array<number>;

  constructor(product: IProduct) {
    this.id = product.id;
    this.name = product.name;
    this.price = product.price;
    this.currency = product.currency;
    this.categories = product.categories;
  }
}
