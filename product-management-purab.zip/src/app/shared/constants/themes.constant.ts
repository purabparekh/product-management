export const THEMES = {
    GREEN: 'spring-green-theme',
    BLUE: 'spring-blue-theme',
};
